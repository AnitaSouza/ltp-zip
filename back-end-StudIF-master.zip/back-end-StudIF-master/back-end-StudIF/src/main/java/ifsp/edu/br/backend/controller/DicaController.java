package ifsp.edu.br.backend.controller;

public class DicaController {
    
}
