package ifsp.edu.br.backend.repository;

public class DicaRepository {
    
    
}
