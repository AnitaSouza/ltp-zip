package br.edu.ifsp.studif.model;

public class CalendarioMuitosParaMuitos {
    
}
