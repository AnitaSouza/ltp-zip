package br.edu.ifsp.studif.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Materias {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String tipo;
    private String descrição;

//Configuração de relacionamentos com o JPA//
    @JsonBackReference
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_dicas")
    private Dicas dicas;

// @JsonManagedReference
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="materias_fk")
    private List<Calendario> calendarios = new ArrayList<>();

    // @JsonManagedReference
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "associacao_materias_calendario", joinColumns = @JoinColumn(name = "fk_materias"), inverseJoinColumns = @JoinColumn(name = "fk_calendario"))
    private List<CalendarioMuitosParaMuitos> calendariosMuitosParaMuitos;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescrição() {
        return descrição;
    }

    public void setDescrição(String descrição) {
        this.descrição = descrição;
    }

    public Dicas getDicas() {
        return dicas;
    }

    public void setDica(Dicas dicas) {
        this.dicas = dicas;
    }

    public List<Calendario> getCalendarios() {
        return calendarios;
    }

    public void setCalendarios(List<Calendario> calendarios) {
        this.calendarios = calendarios;
    }

    public List<CalendarioMuitosParaMuitos> getCalendariosMuitosParaMuitos() {
        return calendariosMuitosParaMuitos;
    }

    public void setCalendariosMuitosParaMuitos(List<CalendarioMuitosParaMuitos> calendariosMuitosParaMuitos) {
        this.calendariosMuitosParaMuitos = calendariosMuitosParaMuitos;
    }


    
}


