package br.edu.ifsp.studif.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import org.springframework.stereotype.Indexed;

@Entity
public class Calendario {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String evento;
    private String data;

    /* Configuração de relacionamentos com o JPA*/
    // Referenciado na classe Livro pelo campo "rotulos"
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn
    @JsonBackReference
    private Materias materias;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Materias getMaterias() {
        return materias;
    }

    public void setMaterias(Materias materias) {
        this.materias = materias;
    }

    
    
    
}
