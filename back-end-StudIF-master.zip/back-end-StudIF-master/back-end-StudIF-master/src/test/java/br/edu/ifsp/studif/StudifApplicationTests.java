package br.edu.ifsp.studif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudifApplicationTests {

	@Test
	void contextLoads() {
	}

}
